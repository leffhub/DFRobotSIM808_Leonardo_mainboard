#include <sim808MobileSMSProvider.h>

SIM808MobileSMSProvider*	SIM808MobileSMSProvider_p;