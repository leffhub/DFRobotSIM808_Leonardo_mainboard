#include <sim808mobileaccessprovider.h>

SIM800MobileAccessProvider* SIM800MobileAccessProvider_t;