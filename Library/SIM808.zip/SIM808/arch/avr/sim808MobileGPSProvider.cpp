#include <sim808MobileGPSProvider.h>

SIM808MobileGPSProvider* SIM808MobileGPSProvider_p;