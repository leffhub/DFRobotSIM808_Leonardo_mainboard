#include <sim808MobileVoiceProvider.h>

SIM808MobileVoiceProvider* SIM808MobileVoiceProvider_t;