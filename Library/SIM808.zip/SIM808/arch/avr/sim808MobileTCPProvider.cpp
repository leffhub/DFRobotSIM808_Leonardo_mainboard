#include <sim808MobileTCPProvider.h>

SIM808MobileTCPProvider* SIM808MobileTCPProvider_p;


