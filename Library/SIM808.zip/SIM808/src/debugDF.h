#ifndef __DEBUGDF__
#define __DEBUGDF__

#define ANDYDEBUG 0
#define SERIALDEBUG 0
#define MGERECDEBUG 0  //Print COM and step
#define SERIALREC 0
#define GPSDEBUG 0

#endif